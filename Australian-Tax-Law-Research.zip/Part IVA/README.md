# Part IVA

This section covers research and resources related to **Part IVA**.

- Legislation references
- Case law summaries
- Notes and PDFs
