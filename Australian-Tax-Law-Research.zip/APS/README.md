# APS

This section covers research and resources related to **APS**.

- Legislation references
- Case law summaries
- Notes and PDFs
