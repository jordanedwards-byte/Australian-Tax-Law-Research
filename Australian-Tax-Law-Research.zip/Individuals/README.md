# Individuals

This section covers research and resources related to **Individuals**.

- Legislation references
- Case law summaries
- Notes and PDFs
