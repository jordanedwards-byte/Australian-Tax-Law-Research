# Losses

This section covers research and resources related to **Losses**.

- Legislation references
- Case law summaries
- Notes and PDFs
