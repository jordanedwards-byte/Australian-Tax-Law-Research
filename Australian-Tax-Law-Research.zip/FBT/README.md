# FBT

This section covers research and resources related to **FBT**.

- Legislation references
- Case law summaries
- Notes and PDFs
