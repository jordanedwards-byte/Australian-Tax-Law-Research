# Income tax consolidation

This section covers research and resources related to **Income tax consolidation**.

- Legislation references
- Case law summaries
- Notes and PDFs
