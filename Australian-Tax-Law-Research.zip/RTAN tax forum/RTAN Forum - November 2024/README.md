# RTAN Forum - November 2024

Details and resources for **RTAN Forum - November 2024** under RTAN tax forum.
