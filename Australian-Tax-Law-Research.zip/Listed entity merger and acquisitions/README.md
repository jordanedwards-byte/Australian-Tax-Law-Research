# Listed entity merger and acquisitions

This section covers research and resources related to **Listed entity merger and acquisitions**.

- Legislation references
- Case law summaries
- Notes and PDFs
