# Employee v contractor

This section covers research and resources related to **Employee v contractor**.

- Legislation references
- Case law summaries
- Notes and PDFs
