# University and CA Notes

This section covers research and resources related to **University and CA Notes**.

- Legislation references
- Case law summaries
- Notes and PDFs
