# Employee share schemes (ESS)

This section covers research and resources related to **Employee share schemes (ESS)**.

- Legislation references
- Case law summaries
- Notes and PDFs
