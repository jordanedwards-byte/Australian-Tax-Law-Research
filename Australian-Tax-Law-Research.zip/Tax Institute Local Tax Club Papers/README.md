# Tax Institute Local Tax Club Papers

This section covers research and resources related to **Tax Institute Local Tax Club Papers**.

- Legislation references
- Case law summaries
- Notes and PDFs
