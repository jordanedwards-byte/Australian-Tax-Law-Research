# Home office

This section covers research and resources related to **Home office**.

- Legislation references
- Case law summaries
- Notes and PDFs
