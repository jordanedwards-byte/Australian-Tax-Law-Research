# State taxes

This section covers research and resources related to **State taxes**.

- Legislation references
- Case law summaries
- Notes and PDFs
