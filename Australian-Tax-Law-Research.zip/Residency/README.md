# Residency

This section covers research and resources related to **Residency**.

- Legislation references
- Case law summaries
- Notes and PDFs
