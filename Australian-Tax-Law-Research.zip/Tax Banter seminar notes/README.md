# Tax Banter seminar notes

This section covers research and resources related to **Tax Banter seminar notes**.

- Legislation references
- Case law summaries
- Notes and PDFs
